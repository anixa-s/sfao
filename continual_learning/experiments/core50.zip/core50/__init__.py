from .deep_slda import deep_slda_core50
