from .icarl import icarl_scifar100
from .gem import gem_scifar100
from .agem import agem_scifar100
from .lamaml import lamaml_scifar100
from .er_ace import erace_scifar100
from .er_aml import eraml_scifar100
from .online_replay import online_replay_scifar100
