from .synaptic_intelligence import synaptic_intelligence_pmnist
from .gem import gem_pmnist
from .ewc import ewc_pmnist
from .agem import agem_pmnist
from .lfl import lfl_pmnist
from .naive import naive_pmnist
from .mir import mir_pmnist
