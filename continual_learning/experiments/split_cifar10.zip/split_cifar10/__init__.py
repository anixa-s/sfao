from .online_replay import online_replay_scifar10
from .mir import mir_scifar10
from .er_ace import erace_scifar10
from .er_aml import eraml_scifar10
from .supervised_contrastive_replay import online_scr_scifar10
