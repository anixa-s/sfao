from .mas import mas_stinyimagenet
from .lwf import lwf_stinyimagenet
from .lamaml import lamaml_stinyimagenet
from .naive import naive_stinyimagenet
from .packnet import packnet_stinyimagenet